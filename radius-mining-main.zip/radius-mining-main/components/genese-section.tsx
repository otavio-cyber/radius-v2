"use client"

import type React from "react"

import { motion } from "framer-motion"
import { useState } from "react"

const pillars = [
  {
    title: "Missão",
    description:
      "Transformar energia disponível em valor sustentável por meio de engenharia, tecnologia e operações eficientes em mineração de Bitcoin.",
  },
  {
    title: "Visão",
    description:
      "Ser referência em projetos de mineração integrados à energia limpa, entregando operações escaláveis e de alta performance.",
  },
  {
    title: "Valores",
    description: "Eficiência energética, precisão técnica, transparência e compromisso com inovação sustentável.",
  },
]

interface GeneseSectionProps {
  onNavigate: (direction: "up") => void
}

export function GeneseSection({ onNavigate }: GeneseSectionProps) {
  const [touchStart, setTouchStart] = useState<{ y: number } | null>(null)

  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStart({ y: e.touches[0].clientY })
  }

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (!touchStart) return

    const deltaY = e.changedTouches[0].clientY - touchStart.y
    const threshold = 50

    if (deltaY > threshold) onNavigate("up")

    setTouchStart(null)
  }

  return (
    <section
      id="genese"
      className="w-full py-24 bg-white relative"
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
    >
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex justify-center mb-8 pt-24">
          <motion.button
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            onClick={() => onNavigate("up")}
            className="w-14 h-14 rounded-full bg-[#8b1fa9]/20 backdrop-blur-md border border-[#8b1fa9]/40 flex items-center justify-center text-[#8b1fa9] hover:bg-[#8b1fa9]/30 transition-all hover:scale-110"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M18 15l-6-6-6 6" />
            </svg>
          </motion.button>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-20 text-center"
        >
          <h2 className="text-4xl md:text-5xl font-bold tracking-tight text-[#1e1b4b] font-['Play']">
            Gênese Radius Mining
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto mt-4">
            A estrutura intelectual e operacional que fundamenta nossa atuação — energia, engenharia e capital em
            sinergia contínua.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-10 mb-28">
          {pillars.map((pillar, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="p-10 bg-white rounded-3xl shadow-[0_8px_30px_rgba(0,0,0,0.06)] border border-gray-100"
            >
              <h3 className="text-xl font-semibold mb-3 text-[#8b1fa9] font-['Play']">{pillar.title}</h3>
              <p className="text-gray-700 leading-relaxed">{pillar.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
